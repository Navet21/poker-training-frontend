export type CardSkin = "flat" | "classic";
