export type Suit = 'S' | 'H' | 'D' | 'C';
