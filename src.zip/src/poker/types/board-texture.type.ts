export type BoardTexture =
  | 'dry'
  | 'semi_coordinated'
  | 'coordinated'
  | 'super_coordinated';
