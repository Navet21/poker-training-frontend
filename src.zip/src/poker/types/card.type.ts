import type { Rank, Suit } from "./";

export type Card = {
  rank: Rank;
  suit: Suit;
};
