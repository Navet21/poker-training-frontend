export type Street = 'flop' | 'turn' | 'river';
