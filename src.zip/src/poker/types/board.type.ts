import type { Card } from "./card.type";


export type Board = Card[];
